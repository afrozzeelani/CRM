// config.js
const BASE_URL = `http://localhost:4000`;
// const BASE_URL = `https://kaspecrm.onrender.com`;
// const BASE_URL = `https://kaspecrm-1.onrender.com`;
export default BASE_URL;
